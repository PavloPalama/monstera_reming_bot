
import logging
from aiogram import Bot, Dispatcher, executor, types
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from datetime import datetime, time

API_TOKEN = '8087919795:AAF6QssHuq33wpi6Dj08oRXRBPDyLhWo89g'

logging.basicConfig(level=logging.INFO)

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)
scheduler = AsyncIOScheduler()

USER_ID = None  # Заповниться автоматично після /start

@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    global USER_ID
    USER_ID = message.from_user.id
    await message.reply("Привіт! Я буду нагадувати тобі поливати та обприскувати монстеру.")

def schedule_reminders():
    scheduler.add_job(send_water_reminder, 'cron', day_of_week='sun,wed', hour=20, minute=0)
    scheduler.add_job(send_spray_reminder, 'cron', day_of_week='sun,tue,thu', hour=8, minute=0)
    scheduler.start()

async def send_water_reminder():
    if USER_ID:
        await bot.send_message(USER_ID, "Сьогодні о 20:00 час полити монстеру!")

async def send_spray_reminder():
    if USER_ID:
        await bot.send_message(USER_ID, "Сьогодні зранку (о 08:00) обприскати листя монстери!")

if __name__ == '__main__':
    schedule_reminders()
    executor.start_polling(dp, skip_updates=True)
